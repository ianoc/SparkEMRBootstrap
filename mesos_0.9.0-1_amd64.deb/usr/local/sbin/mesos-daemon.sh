#!/bin/sh

prefix=/usr/local
exec_prefix=${prefix}

# Increase the default number of open file descriptors.
ulimit -n 8192

PROGRAM=${1}

shift # Remove PROGRAM from the argument list (since we pass ${@} below).

nohup ${exec_prefix}/sbin/${PROGRAM} \
  --conf=${prefix}/var/mesos/conf ${@} </dev/null >/dev/null 2>&1 &
